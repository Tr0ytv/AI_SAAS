"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Bot, Loader2 } from 'lucide-react'

export default function QuestionnairePage() {
  const [isLoading, setIsLoading] = useState(false)
  const [aiResponse, setAiResponse] = useState("")

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setIsLoading(true)
    // Simulate AI processing
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setAiResponse("Based on the information provided, here's a suggested response: ...")
    setIsLoading(false)
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="mb-10 text-3xl font-bold">Security Questionnaire</h1>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Question Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4">
                <div>
                  <Label htmlFor="question">Question</Label>
                  <Input id="question" placeholder="Enter the security question" />
                </div>
                <div>
                  <Label htmlFor="context">Additional Context</Label>
                  <Textarea id="context" placeholder="Provide any relevant context or information" />
                </div>
              </div>
              <Button className="mt-4" type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing
                  </>
                ) : (
                  <>
                    <Bot className="mr-2 h-4 w-4" /> Generate AI Response
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>AI-Generated Response</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={aiResponse}
              placeholder="AI-generated response will appear here"
              rows={10}
              readOnly
            />
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Copy Response
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}


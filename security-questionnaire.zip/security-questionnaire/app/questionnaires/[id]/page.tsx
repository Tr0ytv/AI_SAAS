"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import { MessageSquare, Upload, FileText } from 'lucide-react'

export default function QuestionnairePage() {
  const [comments, setComments] = useState<string[]>([])
  const [newComment, setNewComment] = useState("")

  const addComment = () => {
    if (newComment.trim()) {
      setComments([...comments, newComment])
      setNewComment("")
    }
  }

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">SOC 2 Type II Assessment</h1>
          <div className="mt-2 flex items-center gap-4">
            <Progress value={75} className="w-40" />
            <span className="text-sm text-muted-foreground">75% Complete</span>
          </div>
        </div>
        <div className="flex gap-4">
          <Button variant="outline">
            <Upload className="mr-2 h-4 w-4" />
            Upload Documents
          </Button>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline">
                <MessageSquare className="mr-2 h-4 w-4" />
                Comments
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Comments</SheetTitle>
              </SheetHeader>
              <div className="mt-4 space-y-4">
                {comments.map((comment, index) => (
                  <Card key={index}>
                    <CardContent className="pt-4">
                      <p className="text-sm">{comment}</p>
                    </CardContent>
                  </Card>
                ))}
                <div className="flex gap-2">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment..."
                  />
                  <Button onClick={addComment}>Send</Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Uploaded Documents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                "Security_Policy_2023.pdf",
                "Network_Diagram.pdf",
                "Access_Control_List.xlsx",
              ].map((doc, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between rounded-lg border p-3"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-blue-600" />
                    <span>{doc}</span>
                  </div>
                  <Button variant="ghost" size="sm">
                    View
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Question 1 of 150</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Describe your organization's approach to access control and user
              authentication.
            </p>
            <Textarea
              className="mb-4"
              placeholder="AI-generated response will appear here..."
              rows={6}
            />
            <div className="flex gap-2">
              <Button variant="outline">Regenerate</Button>
              <Button>Save & Continue</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, FileText, MessageSquare, CheckCircle } from 'lucide-react'

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("in-progress")

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-3xl font-bold">Security Questionnaires</h1>
        <Button asChild>
          <Link href="/questionnaires/new">
            New Questionnaire
          </Link>
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
          <TabsTrigger value="in-progress">In Progress</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        <TabsContent value="in-progress" className="mt-6">
          <div className="grid gap-6">
            {[
              {
                title: "SOC 2 Type II Assessment",
                progress: 75,
                comments: 3,
                dueDate: "2024-01-15",
              },
              {
                title: "ISO 27001 Questionnaire",
                progress: 45,
                comments: 1,
                dueDate: "2024-01-20",
              },
            ].map((questionnaire, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{questionnaire.title}</span>
                    <span className="text-sm text-muted-foreground">
                      Due: {questionnaire.dueDate}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <div className="mb-2 flex items-center justify-between text-sm">
                      <span>Progress</span>
                      <span>{questionnaire.progress}%</span>
                    </div>
                    <Progress value={questionnaire.progress} />
                  </div>
                  <div className="flex items-center gap-4">
                    <Button variant="outline" size="sm">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      {questionnaire.comments} Comments
                    </Button>
                    <Button variant="outline" size="sm">
                      Continue
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="completed" className="mt-6">
          <div className="grid gap-6">
            {[
              {
                title: "HIPAA Compliance Assessment",
                completedDate: "2023-12-01",
                questions: 245,
              },
              {
                title: "PCI DSS Questionnaire",
                completedDate: "2023-11-15",
                questions: 178,
              },
            ].map((questionnaire, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{questionnaire.title}</span>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>Completed: {questionnaire.completedDate}</span>
                    <span>{questionnaire.questions} Questions</span>
                  </div>
                  <div className="mt-4">
                    <Button variant="outline" size="sm">
                      View Report
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}


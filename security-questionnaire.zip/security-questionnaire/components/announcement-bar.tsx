export function AnnouncementBar() {
  return (
    <div className="bg-primary py-2 text-center text-sm text-primary-foreground">
      <p>
        Start automating security questionnaires today. Try free for 14 days.
      </p>
    </div>
  )
}


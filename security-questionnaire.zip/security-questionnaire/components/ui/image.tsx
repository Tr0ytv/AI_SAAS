import NextImage, { ImageProps as NextImageProps } from 'next/image'

interface ImageProps extends NextImageProps {
  alt: string
}

export function Image(props: ImageProps) {
  return <NextImage {...props} />
}

